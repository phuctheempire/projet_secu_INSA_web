#!/bin/bash

# Ensure the server IP is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <server_ip>"
    exit 1
fi

SERVER_IP="$1"

# Read session information from session_info.txt
PHPSESSID=$(head -n 1 session_info.txt)
USER_ID=$(tail -n 1 session_info.txt)

# Ensure variables are not empty
if [ -z "$PHPSESSID" ] || [ -z "$USER_ID" ]; then
    echo "Failed to retrieve session information."
    exit 1
fi

# Get the current time in a readable format
CURRENT_TIME=$(date +"%Y-%m-%d %H:%M:%S")

# Construct the URL for the user email page
MAIL_PAGE_URL="http://$SERVER_IP/pages/user/send_email.php?id=$USER_ID"

# Use PHPSESSID and form data to send a POST request, including the current time in the content
response=$(curl -i -L -X POST "$MAIL_PAGE_URL" \
    -b "PHPSESSID=$PHPSESSID" \
    -d "receiver_emails=1" \
    -d "title=1 $CURRENT_TIME" \
    -d "content=Email sent at $CURRENT_TIME" \
    -d "send_email=")

# Check HTTP status code and if the response contains the current time
echo "----------------------------------------"
if echo "$response" | grep -q "200 OK"; then
    echo "Sending email succeeded"
    # Check if the response contains the current time
    if echo "$response" | grep -q "$CURRENT_TIME"; then
        echo "The email content includes the time: $CURRENT_TIME"
    else
        echo "The email content does not include the expected time."
        echo $0 >> failed_log.txt
    fi
else
    echo "Failed to send the email."
    echo $0 >> failed_log.txt
fi
echo "----------------------------------------"
