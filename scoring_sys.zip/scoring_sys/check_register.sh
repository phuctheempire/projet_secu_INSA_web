if [ -z "$1" ]; then
    echo "Usage: $0 <server_ip>"
    exit 1
fi

SERVER_IP="$1"
URL="http://$SERVER_IP/pages/public/register.php"
DATA="nom=Constans&prenom=Mathis&email=Mathis@gmail.com&departement=STI&sexe=M&date_naissance=2003-11-27&adresse=123&telephone=0606060706&annee=2A&password1=1234&password2=1234"
REGISTER_BTN=""



response=$(curl -L -i -X POST $URL -d "DATA" -d "register_btn=$REGISTER_BTN" 2>/dev/null)

echo "----------------------------------------"
    # Check if the HTTP status code is 200 OK
    if echo "$response" | grep -q "200 OK"; then
        echo "HTTP Success"

        if echo "$response" | grep -q "User already exists"; then
          echo "User already register. Launch check_login.sh..."
          ./check_login.sh 
        else
          echo "Enregistrement réussi !"
        fi

    else
        # Deduct 200 points every minute if login fails

        echo "Register failed, HTTP status code: $http_status"

        echo $0 >> failed_log.txt
    fi
echo "----------------------------------------"
