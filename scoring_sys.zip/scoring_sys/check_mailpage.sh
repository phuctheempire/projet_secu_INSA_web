#!/bin/bash
if [ -z "$1" ]; then
    echo "Usage: $0 <server_ip>"
    exit 1
fi

SERVER_IP="$1"

PHPSESSID=$(head -n 1 session_info.txt)
USER_ID=$(tail -n 1 session_info.txt)

if [ -z "$PHPSESSID" ]; then
    echo "Failed to retrieve session info."
    exit 1
fi

MAIL_PAGE_URL="http://$SERVER_IP/pages/user/mail.php?id=$USER_ID"

response=$(curl -i -L -X GET "$MAIL_PAGE_URL" -b "PHPSESSID=$PHPSESSID")


echo "----------------------------------------"

if echo "$response" | grep -q "200 OK"; then
    echo "HTTP Success"
    if echo "$response" | grep -q "Changer mon adresse email"; then
        echo "Email text is present , email page succeeded"
    else
        echo "Email text not found in response"
        echo $0 >> failed_log.txt
    fi
else
    echo "Access to mail page failed"
    echo $0 >> failed_log.txt
fi

echo "----------------------------------------"