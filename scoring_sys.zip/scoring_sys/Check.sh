#!/bin/bash

if [ "$#" -lt 4 ]; then
    echo "Usage: $0 <username> <password> <url> <SERVER_IP> [C] [MP] ..."
    exit 1
fi

username=$1
password=$2
url=$3
SERVER_IP=$4

shift 3

echo "================================================================"
echo "Calling check_login.sh with username: $username, password: $password, url: $url"
./check_login_plus.sh "$username" "$password" "$url"
echo "================================================================"

for check_type in "$@"; do
    case $check_type in
        C)
            echo "================================================================"
            echo "Calling check_contact.sh"
            ./check_contact.sh "SERVER_IP"
            echo "================================================================"
            ;;
        MP)
            echo "================================================================"
            echo "Calling check_mailpage.sh"
            ./check_mailpage.sh "SERVER_IP"
            echo "================================================================"
            ;;
        AP)
            echo "================================================================"
            echo "Calling check_add_post.sh"
            ./check_add_post.sh "SERVER_IP"
            echo "================================================================"
            ;;
        SM)
            echo "================================================================"
            echo "Calling chek_send_mail.sh"
            ./chek_send_mail.sh "SERVER_IP"
            echo "================================================================"
            ;;
        UP)
            echo "================================================================"
            echo "Calling check_userpage.sh"
            ./check_userpage.sh "SERVER_IP"
            echo "================================================================"
            ;;
    esac
done


echo "All checks completed."
