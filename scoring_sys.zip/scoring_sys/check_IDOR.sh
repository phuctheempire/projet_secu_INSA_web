#!/bin/bash
if [ -z "$1" ]; then
    echo "Usage: $0 <server_ip>"
    exit 1
fi

SERVER_IP="$1"
# Lire les informations de session depuis session_info.txt
PHPSESSID=$(head -n 1 session_info.txt)
USER_ID=$((RANDOM % 10 + 1))

# 打印 USER_ID
echo "Random USER_ID: $USER_ID"

# Assurez-vous que les variables ne sont pas vides
if [ -z "$PHPSESSID" ] || [ -z "$USER_ID" ]; then
    echo "Failed to retrieve session information."
    exit 1
fi

# A changer
BASE_URL="http://$SERVER_IP:2024/pages/user/user_page.php?"

# Construire l'URL initiale avec USER_ID
INITIAL_URL="$BASE_URL?id=$USER_ID"


# Envoyer une requête avec la nouvelle URL et le cookie
response=$(curl -i -L -X POST "$MODIFIED_URL" \
    -b "PHPSESSID=$PHPSESSID" \
    )

# Vérifier le statut HTTP et afficher la réponse
echo "----------------------------------------"
if echo "$response" | grep -q "200 OK"; then
    echo "URL modified"

echo "----------------------------------------"
    curl "$MODIFIED_URL"
else
    echo "Failed to modified URL."
fi
echo "----------------------------------------"
