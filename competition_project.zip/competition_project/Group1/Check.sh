#!/bin/bash

if [ "$#" -lt 3 ]; then
    echo "Usage: $0 <username> <password> <url> 
    [CON] check_contact.sh
    [MP] check_mailpage.sh
    [AP] check_add_post.sh
    [SM] check_send_mail.sh
    [UP] check_userpage.sh
    [REG] check_register.sh
    [FS] check_forum_search.sh
    [CS] check_contact_search.sh
    [IDOR] Calling check_IDOR.sh
    [COUR] Calling check_cours.sh
    [NT] Calling check_notes.sh
    [CSRF]Calling check_CSRF.sh"
    exit 1
fi

username=$1
password=$2
SERVER_IP=$3
url="http://$SERVER_IP/pages/public/login.php"


shift 3

echo "================================================================"
echo "Calling check_login.sh with username: $username, password: $password, url: $url"
./check_login_plus.sh "$username" "$password" "$url"
echo "================================================================"

for check_type in "$@"; do
    case $check_type in
        CON)
            echo "================================================================"
            echo "Calling check_contact.sh"
            ./check_contact.sh "$SERVER_IP"
            echo "================================================================"
            ;;
        MP)
            echo "================================================================"
            echo "Calling check_mailpage.sh"
            ./check_mailpage.sh "$SERVER_IP"
            echo "================================================================"
            ;;
        AP)
            echo "================================================================"
            echo "Calling check_add_post.sh"
            ./check_add_post.sh "$SERVER_IP"
            echo "================================================================"
            ;;
        SM)
            echo "================================================================"
            echo "Calling check_send_mail.sh"
            ./check_send_mail.sh "$SERVER_IP"
            echo "================================================================"
            ;;
        UP)
            echo "================================================================"
            echo "Calling check_userpage.sh"
            ./check_userpage.sh "$SERVER_IP"
            echo "================================================================"
            ;;
        REG)
            echo "================================================================"
            echo "Calling check_register.sh"
            ./check_register.sh "$SERVER_IP"
            echo "================================================================"
            ;;
        FS)
            echo "================================================================"
            echo "Calling check_forum_search.sh"
            ./check_forum_search.sh "$SERVER_IP"
            echo "================================================================"
            ;;
        CS)
            echo "================================================================"
            echo "Calling check_contact_search.sh"
            ./check_contact_search.sh "$SERVER_IP"
            echo "================================================================"
            ;;
        IDOR)
            echo "================================================================"
            echo "Calling check_IDOR.sh"
            ./check_IDOR.sh "$SERVER_IP"
            echo "================================================================"
            ;;
        COUR)
            echo "================================================================"
            echo "Calling check_cours.sh"
            ./check_cours.sh "$SERVER_IP"
            echo "================================================================"
            ;;
        NT)
            echo "================================================================"
            echo "Calling check_notes.sh"
            ./check_notes.sh "$SERVER_IP"
            echo "================================================================"
            ;;
        CSRF)
            echo "================================================================"
            echo "Calling check_CSRF.sh"
            ./check_CSRF.sh "$SERVER_IP"
            echo "================================================================"
            ;;
        *)
            echo "Unknown check type: $check_type"
            ;;
    esac
done

echo "All checks completed."
