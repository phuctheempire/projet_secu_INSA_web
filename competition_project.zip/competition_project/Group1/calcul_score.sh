#!/bin/bash

# Fichier contenant la liste des scripts à lire
input_file="failed_log.txt"
score_file="score_test.txt"

# Initialisation du score
#total_points=1000
while true; do

if [[ ! -f "$score_file" ]]; then
	echo "1000" > "$score_file"
fi

total_points=$(<"$score_file")

echo "Score total : $total_points"

# Lecture du fichier ligne par ligne
while IFS= read -r script; do
    # Vérifie si le script est mentionné
    case "$script" in
    "./check_login_plus.sh")
        echo "Script trouvé : $script. Déduction de 10 points."
        total_points=$((total_points - 10))
        ;;
    "./check_register.sh")
        echo "Script trouvé : $script. Déduction de 5 points."
        total_points=$((total_points - 5))
        ;;
    "./check_userpage.sh")
        echo "Script trouvé : $script. Déduction de 5 points."
        total_points=$((total_points - 5))
        ;;
	"./chek_send_mail.sh")
            echo "Script trouvé : $script. Déduction de 5 points."
            total_points=$((total_points - 5))
            ;;
	"./check_receive_mail.sh")
            echo "Script trouvé : $script. Déduction de 5 points."
            total_points=$((total_points - 5))
            ;;
	"./check_mailpage.sh")
            echo "Script trouvé : $script. Déduction de 5 points."
            total_points=$((total_points - 5))
            ;;
	"./check_contact.sh")
            echo "Script trouvé : $script. Déduction de 5 points."
            total_points=$((total_points - 5))
            ;;
	"./check_contact_search.sh")
            echo "Script trouvé : $script. Déduction de 5 points."
            total_points=$((total_points - 5))
            ;;
	"./check_forum_search.sh")
            echo "Script trouvé : $script. Déduction de 5 points."
            total_points=$((total_points - 5))
            ;;
	"./check_cours.sh")
            echo "Script trouvé : $script. Déduction de 5 points."
            total_points=$((total_points - 5))
            ;;
    "./check_notes.sh")
            echo "Script trouvé : $script. Déduction de 5 points."
            total_points=$((total_points - 5))
            ;;
    "./check_add_post.sh")
            echo "Script trouvé : $script. Déduction de 5 points."
            total_points=$((total_points - 5))
            ;;
	"./check_IDOR.sh")
	    echo "Script trouvé : $script. Déduction de 1 points."
	    total_points=$((total_points - 1))
	    ;;
	"./check_CSRF.sh")
	    echo "Script trouvé : $script. Déduction de 5 points."
	    total_points=$((total_points -5))
	   ;;
        *)
            echo "Rien d'autre d'anormal de détecter: $script. Aucun autre point déduit."
            ;;
    esac

#    echo "Score actuel : $total_points"
    echo "--------------------------------"
done < "$input_file"

echo "$total_points" > "$score_file"
echo "Score mis à jour"

#> "$input_file"
#echo "Le fichier $input_file a été vidé"

# Affiche le score final
echo "Score final : $total_points"



    score=$(cat score_test.txt)

    sed -i "2s/Current Score: .*/Current Score: $score/" scores_s.txt
    echo "Score has writed into scores_s.txt :$score"
    echo "Score has writed into scores_s.txt :$score" >> write_score.log

    sleep 10
done
