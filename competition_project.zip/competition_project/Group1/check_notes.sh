#!/bin/bash
if [ -z "$1" ]; then
    echo "Usage: $0 <server_ip>"
    exit 1
fi

SERVER_IP="$1"
# Lire les informations de session depuis le fichier
PHPSESSID=$(head -n 1 session_info.txt)

# Vérifier que PHPSESSID n'est pas vide
if [ -z "$PHPSESSID" ]; then
    echo "Failed to retrieve session info."
    exit 1
fi

# URL de la page des notes
NOTES_PAGE_URL="http://$SERVER_IP/pages/user/note.php"

# Faire une requête GET pour accéder à la page
response=$(curl -i -L -X GET "$NOTES_PAGE_URL" -b "PHPSESSID=$PHPSESSID")

# Vérifier si la réponse contient la matière "JAVA" avec une note de 15
echo "----------------------------------------"
if echo "$response" | grep -q "200 OK"; then
    echo "HTTP Success"
    if echo "$response" | grep -q "note-card"; then
        echo "note-card est présente sur la page."
    else
        echo "note-card n'est pas trouvée sur la page."
        echo $0 >> failed_log.txt
    fi
else
    echo "Echec d'accès à la page des notes."
    echo $0 >> failed_log.txt
fi
echo "----------------------------------------"
