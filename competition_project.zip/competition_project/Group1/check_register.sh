#!/bin/bash

if [ -z "$1" ]; then
    echo "Usage: $0 <server_ip>"
    exit 1
fi

SERVER_IP="$1"
URL="http://$SERVER_IP/pages/public/register.php"

# 生成随机字符串
random_string() {
    openssl rand -hex 4 | tr -d '\n'
}

# 生成随机的用户信息
NOM="user_$(random_string)"
PRENOM="name_$(random_string)"
EMAIL="${PRENOM}.${NOM}@insa-cvl.fr"

DATA="nom=$NOM&prenom=$PRENOM&email=$EMAIL&departement=STI&sexe=M&date_naissance=2003-11-29&adresse=123qwerty&telephone=0606060706&annee=2&password1=1234567&password2=1234567"
REGISTER_BTN=""

LOGIN_URL="http://$SERVER_IP/pages/public/login.php"
PASSWORD="1234567"
LOGIN_BTN=""

# 执行注册请求
response=$(curl -L -i -X POST $URL -d "$DATA" -d "register_btn=$REGISTER_BTN" 2>/dev/null)

echo "----------------------------------------"
# 检查 HTTP 响应状态
if echo "$response" | grep -q "200 OK"; then
    echo "HTTP Success"

    if echo "$response" | grep -q "User already exists"; then
        echo "User already registered: $EMAIL"
    else
        echo "Enregistrement réussi ! Nom: $NOM, Prénom: $PRENOM, Email: $EMAIL"
    fi
else
    echo "Register failed, possible issues encountered."
    echo $0 >> failed_log.txt
fi

# 执行登录请求
response=$(curl -L -i -X POST "$LOGIN_URL" \
    -d "email=$EMAIL" \
    -d "password=$PASSWORD" \
    -d "login_btn=$LOGIN_BTN" )

# 提取 PHPSESSID 和跳转 URL
REDIRECT_URL=$(echo "$response" | grep -oP 'location: \K[^\n]+' | head -n 1)
PHPSESSID=$(echo "$response" | grep -oP 'Set-Cookie: PHPSESSID=\K[^;]+' | head -n 1)

# 清理 URL 并提取用户 ID
CLEAN_REDIRECT_URL=$(echo "$REDIRECT_URL" | xargs)
USER_ID=$(echo "$CLEAN_REDIRECT_URL" | grep -oP 'id=\K\d+')

# 检查是否成功获取 PHPSESSID 或 USER_ID
if [[ -z "$PHPSESSID" || -z "$USER_ID" ]]; then
    echo "Login_Register failed. PHPSESSID or USER_ID is empty."
    echo $0 >> failed_log.txt
else
    echo "Login_Register successful. PHPSESSID: $PHPSESSID, USER_ID: $USER_ID"
fi

echo "----------------------------------------"
