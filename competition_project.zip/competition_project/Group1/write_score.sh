#!/bin/bash
while true; do
    score=$(cat score_test.txt)

    sed -i "2s/Current Score: .*/Current Score: $score/" scores_s.txt
    echo "Score has changed into $score" >> write_score.log

    sleep 10
done
