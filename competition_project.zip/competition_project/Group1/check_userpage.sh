#!/bin/bash
if [ -z "$1" ]; then
    echo "Usage: $0 <server_ip>"
    exit 1
fi

SERVER_IP="$1"
# Read session info from the file
PHPSESSID=$(head -n 1 session_info.txt)
USER_ID=$(tail -n 1 session_info.txt)

# Ensure the variables are not empty
if [ -z "$PHPSESSID" ] || [ -z "$USER_ID" ]; then
    echo "Failed to retrieve session info."
    exit 1
fi

# Construct the URL for the user page
USER_PAGE_URL="http://$SERVER_IP/pages/user/user_page.php?id=$USER_ID"

# Access the user page using PHPSESSID
response=$(curl -i -L -X GET "$USER_PAGE_URL" -b "PHPSESSID=$PHPSESSID")

# Check if HTTP status is 200 OK and the email is in the response
echo "----------------------------------------"
if echo "$response" | grep -q "200 OK"; then
    echo "HTTP Success"
    if echo "$response" | grep -q "User Profile" && echo "$response" | grep -q "Modify User"; then
        echo "User page text found in response succeeded"
    else
        echo "User page text not found in response"
        echo $0 >> failed_log.txt
    fi
else
    echo "Access to user page failed or login failed"
    echo $0 >> failed_log.txt
fi
echo "----------------------------------------"
