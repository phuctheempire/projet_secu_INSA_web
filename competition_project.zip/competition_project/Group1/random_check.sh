#!/bin/bash

# 账号列表 (邮箱 + 密码)
accounts=(
    "student01@insa-cvl.fr 41928028"
    "student02@insa-cvl.fr 86139741"
    "student03@insa-cvl.fr 38971355"
    "student04@insa-cvl.fr 49837016"
    "student05@insa-cvl.fr 33345253"
    "student06@insa-cvl.fr 83138374"
    "student07@insa-cvl.fr 55534937"
    "student08@insa-cvl.fr 76592475"
    "student09@insa-cvl.fr 43321292"
    "student10@insa-cvl.fr 71870973"
    "student11@insa-cvl.fr 40416843"
    "student12@insa-cvl.fr 85111090"
    "student13@insa-cvl.fr 96779155"
    "student14@insa-cvl.fr 35871896"
    "student15@insa-cvl.fr 19891316"
    "student16@insa-cvl.fr 26311954"
    "student17@insa-cvl.fr 61075497"
    "student18@insa-cvl.fr 37847956"
    "student19@insa-cvl.fr 71565425"
    "student20@insa-cvl.fr 64290711"
    "student21@insa-cvl.fr 65402245"
    "student22@insa-cvl.fr 65799413"
    "student23@insa-cvl.fr 75478575"
    "student24@insa-cvl.fr 24943222"
    "student25@insa-cvl.fr 13697941"
    "student26@insa-cvl.fr 44464727"
    "student27@insa-cvl.fr 35172201"
    "student28@insa-cvl.fr 72737312"
    "student29@insa-cvl.fr 36636339"
    "student30@insa-cvl.fr 94574886"
    "student31@insa-cvl.fr 32742369"
    "student32@insa-cvl.fr 28433213"
    "student33@insa-cvl.fr 88026472"
    "student34@insa-cvl.fr 31655184"
    "student35@insa-cvl.fr 65263786"
    "student36@insa-cvl.fr 76744292"
    "student37@insa-cvl.fr 49398570"
    "student38@insa-cvl.fr 40790030"
    "student39@insa-cvl.fr 46909244"
    "student40@insa-cvl.fr 46893344"
    "student41@insa-cvl.fr 80869041"
    "student42@insa-cvl.fr 96747137"
    "student43@insa-cvl.fr 12681067"
    "student44@insa-cvl.fr 44798727"
    "student45@insa-cvl.fr 91321973"
    "student46@insa-cvl.fr 53207442"
    "student47@insa-cvl.fr 81751142"
    "student48@insa-cvl.fr 96334607"
    "student49@insa-cvl.fr 12660034"
    "student50@insa-cvl.fr 42614281"
)

# 检查项列表
checks=(
    "CON"
    "MP"
    "AP"
    "SM"
    "UP"
    "FS"
    "CS"
    "IDOR"
    "COUR"
    "NT"
)

# 目标URL
target_url="10.0.7.177"

# 无限循环，每分钟执行一次
while true; do
    # 随机选择一个账号
    random_account=${accounts[$RANDOM % ${#accounts[@]}]}
    username=$(echo $random_account | awk '{print $1}')
    password=$(echo $random_account | awk '{print $2}')

    # 随机选择2-4个检查项
    num_checks=$((RANDOM % 3 + 2))  # 生成2到4之间的随机数
    selected_checks=()
    for ((i=0; i<$num_checks; i++)); do
        selected_checks+=(${checks[$RANDOM % ${#checks[@]}]})
    done

    # 执行 Check.sh 脚本
    echo "执行命令: ./Check.sh $username $password $target_url ${selected_checks[*]}"
    ./Check.sh "$username" "$password" "$target_url" "${selected_checks[@]}"

    # 等待60秒
    echo "Wait for 30s, the next check is arriving..."
    sleep 30
done
