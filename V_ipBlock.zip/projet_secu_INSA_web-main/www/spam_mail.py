import requests
import threading
import time

# Configuration
BASE_URL = "http://localhost:2024"
LOGIN_URL = f"{BASE_URL}/pages/public/login.php"
MAIL_URL = f"{BASE_URL}/pages/user/mail.php"
THREADS = 1  # Nombre de threads concurrents
REQUESTS_PER_THREAD = 5  # Nombre de requêtes par thread

# Informations de connexion
LOGIN_DATA = {
    "email": "yoann.constans@insa-cvl.fr",
    "password": "123456"
}

# Données pour envoyer un mail
MAIL_DATA = {
    "sender_id": 2,  # ID valide de l'expéditeur
    "emails[]": ["xuan_phuc.pham@insa-cvl.fr"],  # Doit correspondre à l'attente de send_email
    "title": "Test DDoS",
    "content": "This is a test email.",
    "date": "2025-01-01 00:00:00"
}

# Fonction pour se connecter et envoyer des mails
def send_mails():
    with requests.Session() as session:
        # Étape 1 : Se connecter
        login_response = session.post(LOGIN_URL, data=LOGIN_DATA)
        if login_response.status_code != 200:
            print(f"Échec de la connexion : {login_response.status_code}")
            return
        
        print("Connecté avec succès.")

        # Étape 2 : Envoyer plusieurs mails
        for _ in range(REQUESTS_PER_THREAD):
            try:
                mail_response = session.post(MAIL_URL, data=MAIL_DATA)
                if mail_response.status_code == 200:
                    print("Mail envoyé avec succès.")
                else:
                    print(f"Échec de l'envoi du mail, statut : {mail_response.status_code}")
            except requests.RequestException as e:
                print(f"Erreur lors de l'envoi du mail : {e}")

# Lancer plusieurs threads pour simuler un DDoS
threads = []

for i in range(THREADS):
    thread = threading.Thread(target=send_mails)
    threads.append(thread)
    thread.start()

# Attendre que tous les threads soient terminés
for thread in threads:
    thread.join()

print("Simulation terminée.")
