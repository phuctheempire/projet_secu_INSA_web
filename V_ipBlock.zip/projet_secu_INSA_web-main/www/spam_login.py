import requests
import threading
import time

# Paramètres de la cible
URL = "http://localhost:2024/pages/public/login.php"
DATA = {
    "email": "test@example.com",
    "password": "password123"
}
THREADS = 1  # Nombre de threads
REQUESTS_PER_THREAD = 10  # Nombre de requêtes par thread

def send_requests():
    for _ in range(REQUESTS_PER_THREAD):
        try:
            response = requests.post(URL, data=DATA)
            print(f"Requête envoyée avec statut {response.status_code}")
        except requests.exceptions.RequestException as e:
            print(f"Erreur lors de l'envoi de la requête : {e}")

# Lancer plusieurs threads
threads = []

for i in range(THREADS):
    thread = threading.Thread(target=send_requests)
    threads.append(thread)
    thread.start()

# Attendre que tous les threads soient terminés
for thread in threads:
    thread.join()

print("Simulation terminée.")