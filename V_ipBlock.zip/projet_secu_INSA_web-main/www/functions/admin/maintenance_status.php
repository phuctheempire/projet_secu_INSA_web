<?php
// Fichier où sera sauvegardé l'état de maintenance
$maintenance_file = __DIR__ . '/maintenance_flag.txt';

// Lire l'état actuel de la maintenance
if (file_exists($maintenance_file)) {
    $maintenance = file_get_contents($maintenance_file);
} else {
    $maintenance = 0; // Par défaut, pas de maintenance
}


if (isset($_GET['update']) && isset($_GET['value'])) {
    $maintenance = intval($_GET['value']); 
    file_put_contents($maintenance_file, $maintenance); 
}
?>
