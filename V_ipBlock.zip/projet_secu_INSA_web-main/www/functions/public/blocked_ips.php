<?php

// Inclure les fonctions
require "../../controller/config.php"; 


// Chemin vers le fichier contenant les IP bloquées
$blocked_ips_file = ROOT_PATH . "/functions/admin/blocked_ips.txt";

// Vérifier les paramètres dans l'URL
if (isset($_GET['action']) && isset($_GET['ip'])) {
    $ip = $_GET['ip']; // Vulnérable à une injection XSS pour les tests

    if ($_GET['action'] === 'block') {
        blockIp($ip, $blocked_ips_file);
        echo "<script>alert('IP bloquée : {$ip}')</script>"; // Vulnérable au XSS
    } elseif ($_GET['action'] === 'unblock') {
        unblockIp($ip, $blocked_ips_file);
        echo "<script>alert('IP débloquée : {$ip}')</script>"; // Vulnérable au XSS
    }
}

// Fonction pour bloquer une IP
function blockIp($ip, $blocked_ips_file) {
    if (!file_exists($blocked_ips_file)) {
        file_put_contents($blocked_ips_file, ""); // Crée le fichier s'il n'existe pas
    }

    // Lire toutes les IP existantes
    $blocked_ips = file($blocked_ips_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Ajouter l'IP si elle n'est pas déjà bloquée
    if (!in_array($ip, $blocked_ips)) {
        file_put_contents($blocked_ips_file, $ip . PHP_EOL, FILE_APPEND);
    }
}

// Fonction pour débloquer une IP
function unblockIp($ip, $blocked_ips_file) {
    if (!file_exists($blocked_ips_file)) {
        return; // Si le fichier n'existe pas, rien à faire
    }

    // Lire toutes les IP existantes
    $blocked_ips = file($blocked_ips_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Supprimer l'IP de la liste
    $updated_ips = array_filter($blocked_ips, function($blocked_ip) use ($ip) {
        return $blocked_ip !== $ip;
    });

    // Réécrire le fichier avec les IP restantes
    file_put_contents($blocked_ips_file, implode(PHP_EOL, $updated_ips) . PHP_EOL);
}
?>
