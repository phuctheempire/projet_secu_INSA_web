<?php


function getAllMailsByID($id) {
    global $conn;
    $query = "SELECT mail_id, sender_id, receiver_id, title, date FROM Mails WHERE sender_id = $id OR receiver_id = $id ORDER BY date DESC";
    $result = mysqli_query($conn, $query);
    $mails = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $mails[] = $row;
    }
    return $mails;
}

/*
function send_email($email_cont) {
    global $conn;
    $sender_id = $email_cont['sender_id'];
    $receiver_ids = get_id_by_email($email_cont['emails']);
    $title = $email_cont['title'];
    $content = $email_cont['content'];
    $date = $email_cont['date'];
    $error_not_sent = [];
    for ($i = 0; $i < count($receiver_ids); $i++) {
        $receiver_id = $receiver_ids[$i];
        $query = "INSERT INTO Mails (sender_id, receiver_id, title, content, date) VALUES ('$sender_id', '$receiver_id', '$title', '$content', '$date')";
        $result = mysqli_query($conn, $query);
        if (!$result) {
            array_push($error_not_sent, $receiver_id);
        }
    }
    return $error_not_sent;
}
*/


//---------------------------------
function send_email($email_cont) {
    global $conn;

    // Détection des tentatives globales d'envoi d'e-mails
    $current_time = time();
    $threshold = 2; // Nombre total d'e-mails autorisés par minute
    $block_duration = 300; // Durée de blocage en secondes (5 minutes)

    // Vérifier les tentatives globales
    $query = "SELECT attempts, last_attempt FROM global_email_attempts LIMIT 1";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $attempts = $row['attempts'];
        $last_attempt = $row['last_attempt'];

        if ($attempts >= $threshold && ($current_time - $last_attempt) < $block_duration) {
            // Retourne un code HTTP 429 au lieu d'exécuter le reste de la fonction
            header("HTTP/1.1 429 Too Many Requests");
            echo "<html>
                    <head>
                        <title>Service temporairement indisponible</title>
                    </head>
                    <body style='font-family: Arial, sans-serif; text-align: center; margin-top: 20%;'>
                        <h1 style='color: red;'>Le système d'envoi d'e-mails est temporairement bloqué</h1>
                        <p>Nous avons détecté un nombre élevé de tentatives d'envoi. Veuillez réessayer dans quelques minutes.</p>
                        <p><strong>Temps restant estimé :</strong> " . ceil(($block_duration - ($current_time - $last_attempt)) / 60) . " minute(s).</p>
                    </body>
                  </html>";
            exit; // Empêche toute exécution supplémentaire
        } elseif (($current_time - $last_attempt) >= $block_duration) {
            // Réinitialiser les tentatives après la durée de blocage
            $query = "UPDATE global_email_attempts SET attempts = 0, last_attempt = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $current_time);
            $stmt->execute();
        }
    } else {
        // Insérer un nouvel enregistrement si aucune tentative n'a encore été enregistrée
        $query = "INSERT INTO global_email_attempts (attempts, last_attempt) VALUES (0, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $current_time);
        $stmt->execute();
    }

    // Incrémenter les tentatives globales
    $query = "UPDATE global_email_attempts SET attempts = attempts + 1, last_attempt = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $current_time);
    $stmt->execute();

    // Envoi des e-mails
    $sender_id = $email_cont['sender_id'];
    $receiver_ids = get_id_by_email($email_cont['emails']);
    $title = $email_cont['title'];
    $content = $email_cont['content'];
    $date = $email_cont['date'];
    $error_not_sent = [];

    for ($i = 0; $i < count($receiver_ids); $i++) {
        $receiver_id = $receiver_ids[$i];
        $query = "INSERT INTO Mails (sender_id, receiver_id, title, content, date) VALUES ('$sender_id', '$receiver_id', '$title', '$content', '$date')";
        $result = mysqli_query($conn, $query);
        if (!$result) {
            array_push($error_not_sent, $receiver_id);
        }
    }
    return $error_not_sent;
}


//---------------------------------

function get_id_by_email($email_list) {
    global $conn;
    $ids = [];
    for ($i = 0; $i < count($email_list); $i++) {
        $email_tmp = $email_list[$i];
        $query = "SELECT id FROM Users WHERE email = '$email_tmp' LIMIT 1";
        $result = mysqli_query($conn, $query);
        $row = mysqli_fetch_assoc($result);
        if ($row){
            array_push($ids, $row["id"]);
        }
    }
    return $ids;
}
function get_email_by_id($id) {
    global $conn;
    $query = "SELECT email FROM Users WHERE id = $id LIMIT 1";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['email'];
}

function get_email_detail( $id){
    global $conn;
    $query = "SELECT * FROM Mails WHERE mail_id = '$id' LIMIT 1";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    return $row;
}

