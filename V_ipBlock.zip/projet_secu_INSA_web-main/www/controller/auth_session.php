<?php

require "../../controller/config.php";
require ROOT_PATH . DS . "functions" . DS . "admin" . DS . "maintenance_status.php";


if ($maintenance == 1) {
    header("Location: /pages/public/maintenance.php");
    exit;
}



// variable declaration
$username = "";
$email = "";
$errors = array();

//------------------------------
// Database connection (assurez-vous que $conn est correctement initialisé)
if (!isset($conn)) {
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
}

// Détection des tentatives 
$current_time = time();
$threshold = 5; // Nombre total de tentatives autorisées dans la fenêtre de temps
$block_duration = 30; // Durée de blocage en secondes (5 minutes)

// Vérifier les tentatives globales
$query = "SELECT attempts, last_attempt FROM global_login_attempts LIMIT 1";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $attempts = $row['attempts'];
    $last_attempt = $row['last_attempt'];

    // Si les tentatives dépassent le seuil et que le blocage est encore actif
    if ($attempts >= $threshold && ($current_time - $last_attempt) < $block_duration) {
        header("HTTP/1.1 429 Too Many Requests");
        die("<h1>Site sous attaque DDoS. Veuillez réessayer plus tard.</h1>");
    } elseif (($current_time - $last_attempt) >= $block_duration) {
        // Réinitialiser les tentatives après la durée de blocage
        $query = "UPDATE global_login_attempts SET attempts = 0, last_attempt = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $current_time);
        $stmt->execute();
    }
} else {
    // Insérer un nouvel enregistrement si aucune tentative n'a encore été enregistrée
    $query = "INSERT INTO global_login_attempts (attempts, last_attempt) VALUES (0, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $current_time);
    $stmt->execute();
}

// Incrémenter les tentatives globales en cas d'accès au formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $query = "UPDATE global_login_attempts SET attempts = attempts + 1, last_attempt = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $current_time);
    $stmt->execute();
}

//------------------------------


if (isset($_POST['login_btn'])) {
    // Chemin vers le fichier contenant les IP bloquées
$blocked_ips_file = ROOT_PATH . "/functions/admin/blocked_ips.txt";

// Fonction pour vérifier si une IP est bloquée
function isIpBlocked($ip, $blocked_ips_file) {
    if (!file_exists($blocked_ips_file)) {
        echo "<html>
            <head>
                <title>fichier non trouvé</title>
            </head>
          </html>";
    }

    // Lire toutes les IP bloquées depuis le fichier
    $blocked_ips = file($blocked_ips_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return in_array($ip, $blocked_ips); // Vérifie si l'IP actuelle est dans la liste
}

// Obtenir l'adresse IP de l'utilisateur
$user_ip = $_SERVER['REMOTE_ADDR']; // Récupère l'IP de l'utilisateur

echo $user_ip;

// Vérifier si l'IP est bloquée
if (isIpBlocked($user_ip, $blocked_ips_file)) {
    // Afficher une page HTML si l'IP est bloquée
    echo "<html>
            <head>
                <title>IP Bloquée</title>
            </head>
            <body style='font-family: Arial, sans-serif; text-align: center; margin-top: 20%;'>
                <h1 style='color: red;'>Ton IP est bloquée</h1>
                <p>Reviens plus tard.</p>
            </body>
          </html>";
    exit; // Empêche toute exécution supplémentaire
}
//------------------------------


    $email = ($_POST['email']);
    $password = ($_POST['password']);
    if (empty($email)) {
        array_push($errors, "Email required");
    }
    if (empty($password)) {
        array_push($errors, "Password required");
    }
    if (empty($errors)) {
        $sql = "SELECT * FROM Users WHERE email = '$email' AND password = '$password' LIMIT 1;";
        $result = mysqli_query($conn, $sql);
        // var_dump($result);
        // echo mysqli_num_rows($result);
        if (mysqli_num_rows($result) > 0) {
            // get id of created user
            $reg_user = mysqli_fetch_assoc($result);
            $_SESSION['user_id'] = $reg_user['id'];
            $_SESSION['user_role'] = $reg_user['role'];
            // die();
            // put logged in user into session array
            // if user is admin, redirect to admin area
            // redirect to public area
            header('location: /pages/user/user_page.php?id=' . urlencode($_SESSION['user_id']));
            exit(0);
        } else {
            array_push($errors, 'Wrong credentials');
        }
    }
}

if (isset($_POST['register_btn'])) {
    // Get form inputs]
    $nom = strtoupper($_POST['nom']);
    $prenom = ($_POST['prenom']);
    $email = ($_POST['email']);
    $departement = ($_POST['departement']);
    $sexe = ($_POST['sexe']);
    $date_naissance = ($_POST['date_naissance']);
    $adresse = ($_POST['adresse']);
    $telephone = ($_POST['telephone']);
    $annee = ($_POST['annee']);
    $password1 = ($_POST['password1']);
    $password2 = ($_POST['password2']);

    // Validate form inputs
    if (empty($nom)) {
        array_push($errors, "Nom required");
    }
    if (empty($prenom)) {
        array_push($errors, "Prenom required");
    }
    if (empty($email)) {
        array_push($errors, "Email required");
    }
    if (empty($departement)) {
        array_push($errors, "Departement required");
    }
    if (empty($sexe)) {
        array_push($errors, "Sexe required");
    }
    if (empty($date_naissance)) {
        array_push($errors, "Date de Naissance required");
    }
    if (empty($adresse)) {
        array_push($errors, "Adresse required");
    }
    if (empty($telephone)) {
        array_push($errors, "Telephone required");
    }
    if (empty($annee)) {
        array_push($errors, "Annee required");
    }
    if (empty($password1)) {
        array_push($errors, "Password required");
    }
    if (empty($password2)) {
        array_push($errors, "Password confirmation required");
    }
    if ($password1 != $password2) {
        array_push($errors, "Passwords do not match");
    }

    // Check if username or email already exists
    $user_check_query = "SELECT * FROM Users WHERE email='$email' LIMIT 1";
    $result = mysqli_query($conn, $user_check_query);

    if ($result) { // If user exists
        if (mysqli_num_rows($result) > 0) {
            array_push($errors, "Email already exists");
        }
    }
    global $conn;
    // If no errors, register user
    if (empty($errors)) {
        $password = $password1; // Encrypt password before saving in database
        $img = $nom . "_" . strtolower(str_replace(" ", "_", $prenom)) . ".jpg";
        $query = "INSERT INTO `Users` (email, password, nom, prenom, sexe, date_naissance, adresse, telephone, image_path, role) VALUES ('$email', '$password', '$nom', '$prenom', '$sexe', '$date_naissance', '$adresse', '$telephone', '$img', 'Student');";
        // var_dump($query);
        if (!$result = mysqli_query($conn, $query)) {
            header('location: /index.php');
        }
        $query2 = "SELECT id FROM `Users` WHERE email = '$email'";
        if (!$result = mysqli_query($conn, $query2)) {
            header('location: /index.php');
        } else {
            $new_id = mysqli_fetch_assoc($result)['id'];
        }
        $query3 = "INSERT INTO `Students` (stu_id, departement) VALUES ($new_id, '$departement');";
        if (!$result = mysqli_query($conn, $query3)) {
            header('location: /index.php');
        }
        $_SESSION['user_id'] = $new_id;
        header('location: /pages/user/user_page.php?id=' . urlencode($_SESSION['user_id']));
    }
}

function getUserById($id)
{
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    // global $conn;
    $sql = "SELECT * FROM Users WHERE id=$id"; //requête qui récupère le user et son rôle
    $result = mysqli_query($conn, $sql);//la fonction php-mysql
    $user = mysqli_fetch_assoc($result);//je met $result au format associatif
    return $user;
}

?>