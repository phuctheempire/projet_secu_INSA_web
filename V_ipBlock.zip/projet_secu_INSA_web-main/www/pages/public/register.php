<?php
require "../../controller/config.php";
require ROOT_PATH . DS . "controller" . DS . "auth_session.php";


require ROOT_PATH . DS . "functions" . DS . "admin" . DS . "maintenance_status.php";


if ($maintenance == 1) {
    header("Location: /pages/public/maintenance.php");
    exit;
}



// Détection des tentatives globales d'enregistrement
$current_time = time();
$threshold = 3; // Nombre d'enregistrements autorisés par minute
$block_duration = 300; // Durée de blocage en secondes (5 minutes)

// Connexion à la base de données
if (!isset($conn)) {
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (!$conn) {
        die("Erreur de connexion à la base de données : " . mysqli_connect_error());
    }
}

// Vérifier les tentatives globales
$query = "SELECT attempts, last_attempt FROM global_register_attempts LIMIT 1";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $attempts = $row['attempts'];
    $last_attempt = $row['last_attempt'];

    // Bloquer si le seuil est atteint
    if ($attempts >= $threshold && ($current_time - $last_attempt) < $block_duration) {
        echo "<html>
                <head>
                    <title>Service temporairement indisponible</title>
                </head>
                <body style='font-family: Arial, sans-serif; text-align: center; margin-top: 20%;'>
                    <h1 style='color: red;'>Le service d'inscription est temporairement bloqué</h1>
                    <p>Nous avons détecté un nombre élevé de tentatives d'enregistrement. Veuillez réessayer dans quelques minutes.</p>
                    <p><strong>Temps restant estimé :</strong> " . ceil(($block_duration - ($current_time - $last_attempt)) / 60) . " minute(s).</p>
                </body>
              </html>";
        exit; // Empêche toute exécution supplémentaire
    } elseif (($current_time - $last_attempt) >= $block_duration) {
        // Réinitialiser les tentatives après la durée de blocage
        $query = "UPDATE global_register_attempts SET attempts = 0, last_attempt = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $current_time);
        $stmt->execute();
    }
} else {
    // Insérer un nouvel enregistrement si aucune tentative n'a encore été enregistrée
    $query = "INSERT INTO global_register_attempts (attempts, last_attempt) VALUES (0, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $current_time);
    $stmt->execute();
}

// Incrémenter les tentatives globales
$query = "UPDATE global_register_attempts SET attempts = attempts + 1, last_attempt = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $current_time);
$stmt->execute();


//---------------------------------
    // Chemin vers le fichier contenant les IP bloquées
    $blocked_ips_file = ROOT_PATH . "/functions/admin/blocked_ips.txt";

    // Fonction pour vérifier si une IP est bloquée
    function isIpBlocked($ip, $blocked_ips_file) {
        if (!file_exists($blocked_ips_file)) {
            echo "<html>
                <head>
                    <title>fichier non trouvé</title>
                </head>
              </html>";
        }
    
        // Lire toutes les IP bloquées depuis le fichier
        $blocked_ips = file($blocked_ips_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        return in_array($ip, $blocked_ips); // Vérifie si l'IP actuelle est dans la liste
    }
    
    // Obtenir l'adresse IP de l'utilisateur
    $user_ip = $_SERVER['REMOTE_ADDR']; // Récupère l'IP de l'utilisateur
    
    echo $user_ip;
    
    // Vérifier si l'IP est bloquée
    if (isIpBlocked($user_ip, $blocked_ips_file)) {
        // Afficher une page HTML si l'IP est bloquée
        echo "<html>
                <head>
                    <title>IP Bloquée</title>
                </head>
                <body style='font-family: Arial, sans-serif; text-align: center; margin-top: 20%;'>
                    <h1 style='color: red;'>Ton IP est bloquée</h1>
                    <p>Reviens plus tard.</p>
                </body>
              </html>";
        exit; // Empêche toute exécution supplémentaire
    }



//---------------------------------


include ROOT_PATH . DS . "components" . DS . "header.php";
require ROOT_PATH . DS . "components" . DS . "nav_bar.php";
?>

<body>

    <div class="container">
        <?php include ROOT_PATH.DS.'components'.DS."error.php" ?>
        <form method="post" action="register.php" id="registration-form">
            <h2 class="form-title">Register</h2> <!-- Added a title for the form -->
            
            <div class="form-group">
                <input type="text" name="nom" placeholder="Nom" 
                    class="form-input" id="nom" required>
            </div>
            <div class="form-group">
                <input type="text" name="prenom" placeholder="Prenom" 
                    class="form-input" id="prenom" required>
            </div>
            <div class="form-group">
                <input type="text" name="email" placeholder="Email"
                     class="form-input" id="email" required>
            </div>
            <div class="form-group">
                <label for="departement">Select Department:</label>
                <select name="departement" id="departement" class="form-select" required>
                    <option value="">-- Select Department --</option>
                    <option value="STI">STI</option>
                    <option value="MRI">MRI</option>
                    <option value="GSI">GSI</option>
                </select>
            </div>
            <div class="form-group">
                <label for="sexe">Sexe:</label>
                <select name="sexe" id="sexe" class="form-select" required>
                    <option value="">-- Select Sexe --</option>
                    <option value="M">M</option>
                    <option value="F">F</option>
                </select>
            </div>
            <div class="form-group">
                <label for="date_naissance">Date de Naissance:</label>
                <input type="date" name="date_naissance" class="form-input" id="date_naissance" required>
            </div>

            <div class="form-group">
                <input type="text" name="adresse" placeholder="Adresse" 
                    class="form-input" id="adresse" required>
            </div>

            <div class="form-group">
                <input type="tel" name="telephone" placeholder="Telephone" 
                    class="form-input" id="telephone" required>
            </div>

            <div class="form-group">
                <label for="annee">Année:</label>
                <select name="annee" id="annee" class="form-select" required>
                    <option value="">-- Select Année --</option>
                    <option value="1A">1</option>
                    <option value="2A">2</option>
                    <option value="3A">3</option>
                    <option value="4A">4</option>
                    <option value="5A">5</option>
                </select>
            </div>

            <div class="form-group">
                <input type="password" name="password1" placeholder="Password" class="form-input" id="password1"
                    required>
            </div>
            <div class="form-group">
                <input type="password" name="password2" placeholder="Password confirmation" class="form-input"
                    id="password2" required>
            </div>
            <button type="submit" name="register_btn" class="form-button">Register</button>
        </form>


    </div>
</body>