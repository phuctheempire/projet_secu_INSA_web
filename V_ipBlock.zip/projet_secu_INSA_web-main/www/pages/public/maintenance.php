<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance</title>
</head>
<body style="font-family: Arial, sans-serif; text-align: center; margin-top: 20%;">
    <h1 style="color: red;">Site en Maintenance</h1>
    <p>Le site est actuellement en maintenance. Veuillez réessayer plus tard.</p>
</body>
</html>
