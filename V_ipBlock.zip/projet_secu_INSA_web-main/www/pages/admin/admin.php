<?php
require "../../controller/config.php";
require ROOT_PATH . DS . "controller" . DS . "auth_session.php";
include ROOT_PATH . DS . "components" . DS . "header.php";
require ROOT_PATH . DS . "components" . DS . "nav_bar.php";
?>
<body>
    <div class="container">
        <div class="card">Users</div>
        <div class="card">Cours</div>
    </div>
</body>