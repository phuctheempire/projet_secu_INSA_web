import requests
import threading

# Configuration
BASE_URL = "http://localhost:2024"
REGISTER_URL = f"{BASE_URL}/pages/public/register.php"
THREADS = 1  # Nombre de threads concurrents
REQUESTS_PER_THREAD = 2  # Nombre de requêtes par thread

# Données pour l'inscription
REGISTER_DATA = {
    "nom": "TestNom",
    "prenom": "TestPrenom",
    "email": "testt{counter}@example.com",  # Ajout d'un compteur pour éviter les doublons
    "departement": "STI",
    "sexe": "M",
    "date_naissance": "2000-01-01",
    "adresse": "12ff, rue de la rue",
    "telephone": "1234567890",
    "annee": "1A",
    "password1": "Password123",
    "password2": "Password123",
    "register_btn": "Register"
}

# Fonction pour envoyer les tentatives d'inscription
def register_attempts(thread_id):
    with requests.Session() as session:
        for i in range(REQUESTS_PER_THREAD):
            try:
                # Mettre à jour l'adresse e-mail pour chaque tentative
                data = REGISTER_DATA.copy()
                data["email"] = f"test{thread_id * REQUESTS_PER_THREAD + i}@example.com"

                response = session.post(REGISTER_URL, data=data)
                print(f"Tentative {i + 1} (Thread {thread_id}) : Statut {response.status_code} - Réponse {response.text[:100]}")
            except requests.RequestException as e:
                print(f"Erreur lors de la tentative d'inscription : {e}")

# Lancer plusieurs threads pour simuler des requêtes simultanées
threads = []

for thread_id in range(THREADS):
    thread = threading.Thread(target=register_attempts, args=(thread_id,))
    threads.append(thread)
    thread.start()

# Attendre que tous les threads soient terminés
for thread in threads:
    thread.join()

print("Simulation terminée.")
